from fastapi import FastAPI, HTTPException
from sqlmodel import select
import stripe

from app.db.db_connector import create_db_and_tables, DB_SESSION


async def lifespan(app: FastAPI):
    print("create tables ....")
    create_db_and_tables()
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/")
def home():
    return "Payment Service"


